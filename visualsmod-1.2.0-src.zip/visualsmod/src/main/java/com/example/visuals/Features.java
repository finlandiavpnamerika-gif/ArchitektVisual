package com.example.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.SimpleOption;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.effect.StatusEffectInstance;
import org.joml.Matrix3x2fStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class Features {
    private Features() {}

    private static double origGamma = -1.0;
    private static int origFov = -1;
    private static int origView = -1;

    public static void tick(MinecraftClient mc) {
        if (mc.options == null) return;
        GameOptions o = mc.options;

        // Fullbright
        SimpleOption<Double> gamma = o.getGamma();
        if (Config.fullbright) {
            if (origGamma < 0) origGamma = gamma.getValue();
            if (gamma.getValue() != Config.gamma) gamma.setValue(Config.gamma);
        } else if (origGamma >= 0) {
            gamma.setValue(origGamma);
            origGamma = -1.0;
        }

        // Zoom
        SimpleOption<Integer> fov = o.getFov();
        boolean zooming = Config.zoom && VisualsClient.zoomKey.isPressed() && mc.currentScreen == null;
        if (zooming) {
            if (origFov < 0) origFov = fov.getValue();
            int target = (int) Config.zoomFov;
            if (fov.getValue() != target) fov.setValue(target);
        } else if (origFov >= 0) {
            fov.setValue(origFov);
            origFov = -1;
        }

        // Лимит дальности
        SimpleOption<Integer> view = o.getViewDistance();
        if (Config.limitDist) {
            if (origView < 0) origView = view.getValue();
            int target = (int) Config.viewDist;
            if (view.getValue() != target) view.setValue(target);
        } else if (origView >= 0) {
            view.setValue(origView);
            origView = -1;
        }

        // AutoSprint
        if (mc.player != null && Config.sprint && mc.currentScreen == null
                && !mc.player.isSneaking() && !mc.player.isUsingItem()
                && mc.player.getHungerManager().getFoodLevel() > 6) {
            boolean fwd = o.forwardKey.isPressed();
            boolean any = fwd || o.backKey.isPressed() || o.leftKey.isPressed() || o.rightKey.isPressed();
            if (Config.sprintAllDirs ? any : fwd) {
                mc.player.setSprinting(true);
            }
        }
    }

    /** Возвращает настройки игры в исходное состояние (при выходе). */
    public static void restore(MinecraftClient mc) {
        try {
            if (origGamma >= 0) mc.options.getGamma().setValue(origGamma);
            if (origFov >= 0) mc.options.getFov().setValue(origFov);
            if (origView >= 0) mc.options.getViewDistance().setValue(origView);
        } catch (Exception ignored) {
        }
        origGamma = -1.0;
        origFov = -1;
        origView = -1;
    }

    private static String time(StatusEffectInstance e) {
        if (e.isInfinite()) return "inf";
        int s = e.getDuration() / 20;
        return String.format(Locale.ROOT, "%02d:%02d", s / 60, s % 60);
    }

    public static void hud(DrawContext g, RenderTickCounter tick) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!Config.hud || mc.player == null || mc.options.hudHidden) return;
        TextRenderer tr = mc.textRenderer;

        List<String> lines = new ArrayList<>();
        if (Config.hudFps) lines.add("FPS: " + mc.getCurrentFps());
        if (Config.hudPing) {
            PlayerListEntry entry = mc.getNetworkHandler() == null
                    ? null : mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
            lines.add("Ping: " + (entry == null ? 0 : entry.getLatency()) + " ms");
        }
        if (Config.hudCoords) {
            lines.add(String.format(Locale.ROOT, "X: %.1f / Y: %.1f / Z: %.1f",
                    mc.player.getX(), mc.player.getY(), mc.player.getZ()));
        }
        if (Config.hudFacing) {
            String f = mc.player.getHorizontalFacing().name().toLowerCase(Locale.ROOT);
            lines.add(Character.toUpperCase(f.charAt(0)) + f.substring(1));
        }

        List<String> effects = new ArrayList<>();
        if (Config.hudEffects) {
            for (StatusEffectInstance e : mc.player.getStatusEffects()) {
                String name = e.getEffectType().value().getName().getString();
                if (e.getAmplifier() > 0) name = name + " " + (e.getAmplifier() + 1);
                effects.add(name + "  " + time(e));
            }
        }

        String title = "VisualsMod v1.2";
        int w = tr.getWidth(title);
        for (String s : lines) w = Math.max(w, tr.getWidth(s));
        for (String s : effects) w = Math.max(w, tr.getWidth(s));
        int h = 14 + lines.size() * 10 + (effects.isEmpty() ? 0 : 14 + effects.size() * 10) + 4;

        Matrix3x2fStack m = g.getMatrices();
        m.pushMatrix();
        m.translate((float) Config.hudX, (float) Config.hudY);
        m.scale((float) Config.hudScale, (float) Config.hudScale);

        int color = Config.COLORS[Config.hudColor];
        g.fill(0, 0, w + 10, h, 0x90000000);
        g.fill(0, 0, 2, h, color);

        int y = 3;
        g.drawTextWithShadow(tr, title, 6, y, color);
        y += 12;
        for (String s : lines) {
            g.drawTextWithShadow(tr, s, 6, y, -1);
            y += 10;
        }
        if (!effects.isEmpty()) {
            y += 3;
            g.drawTextWithShadow(tr, "POTION EFFECTS", 6, y, color);
            y += 11;
            for (String s : effects) {
                g.drawTextWithShadow(tr, s, 6, y, -1);
                y += 10;
            }
        }
        m.popMatrix();
    }
}
